package com.tyustwys.logindemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

/**
 * Created by weiyashuai on 2017/4/10.
 */

public class RegisterActivity extends AppCompatActivity {
    private EditText edt_username,edt_password;
    private RadioGroup rgp_sex;
    private Button btn_back,btn_reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        initViews();
        initAction();
    }

    private void initAction() {
        btn_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = edt_username.getText().toString();
                String password = edt_password.getText().toString();
                String sex = ((RadioButton)findViewById(rgp_sex.getCheckedRadioButtonId())).getText().toString();
                Teacher teacher = new Teacher(username,password,sex);
                teacher.signUp(new SaveListener<Teacher>() {
                    @Override
                    public void done(Teacher teacher, BmobException e) {
                        if (e==null){
                            shortToast("注册成功");//简化的toast方法
                            finish();
                        }
                        else {
                            shortToast("注册失败"+e.getMessage());
                        }
                    }
                });
            }
        });
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void initViews() {
        edt_username = (EditText) findViewById(R.id.edt_username_reg);
        edt_password = (EditText) findViewById(R.id.edt_password_reg);
        rgp_sex = (RadioGroup) findViewById(R.id.rg_sex_reg);
        btn_back = (Button) findViewById(R.id.btn_back_reg);
        btn_reg = (Button) findViewById(R.id.btn_register_reg);
        rgp_sex.check(R.id.rb_sex_1);
    }
    private void shortToast(String toast){
        Toast.makeText(RegisterActivity.this, toast, Toast.LENGTH_SHORT).show();
    }
    private void startAct(Class<?> cla){
        Intent intent = new Intent(RegisterActivity.this,cla);
        startActivity(intent);
    }
}
