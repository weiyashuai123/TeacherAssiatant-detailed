package com.tyustwys.logindemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * Created by weiyashuai on 2017/4/10.
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
