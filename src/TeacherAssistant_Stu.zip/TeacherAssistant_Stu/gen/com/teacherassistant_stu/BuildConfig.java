/** Automatically generated file. DO NOT MODIFY */
package com.teacherassistant_stu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}