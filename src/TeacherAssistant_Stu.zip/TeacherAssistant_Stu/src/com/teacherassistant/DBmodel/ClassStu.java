package com.teacherassistant.DBmodel;

import cn.bmob.v3.BmobObject;

public class ClassStu extends BmobObject{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String stuName;
	private String className;
	private String teacher;
	
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	
	
}
