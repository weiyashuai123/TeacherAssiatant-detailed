package com.teacherassistant.ui.fragment;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.teacherassistant.DBmodel.ClassStu;
import com.teacherassistant.DBmodel.Classes;
import com.teacherassistant.DBmodel.SignInfo;
import com.teacherassistant_stu.R;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobDate;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;

public class Fragment_callname extends Fragment implements OnClickListener {

	private View view;
	private TextView tv_stuid;
	private TextView tv_stuname;
	private TextView tv_classname;
	private Button btn_sign;
	private String provider;
	private LocationManager locationManager;

	private Dialog classlist_dialog;
	private ListView list_class;
	private SimpleAdapter classlist_adapter;

	private String classteacher;

	private List<HashMap<String, Object>> mapLists = null;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		view = inflater.inflate(R.layout.fragment_callname_main, container, false);

		btn_sign = (Button) view.findViewById(R.id.btn_sign_callname);
		tv_classname = (TextView) view.findViewById(R.id.tv_stuClass_callname);
		tv_stuid = (TextView) view.findViewById(R.id.tv_stuId_callname);
		tv_stuname = (TextView) view.findViewById(R.id.tv_stuName_callname);

		SharedPreferences sp = getActivity().getSharedPreferences("RememberUser", Context.MODE_PRIVATE);
		tv_stuname.setText(sp.getString("realname", ""));
		tv_stuid.setText("ѧ��" + sp.getString("stuid", ""));

		locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
		List<String> providerList = locationManager.getProviders(true);
		if (providerList.contains(LocationManager.GPS_PROVIDER)) {
			provider = LocationManager.GPS_PROVIDER;
		} else if (providerList.contains(LocationManager.NETWORK_PROVIDER)) {
			provider = LocationManager.NETWORK_PROVIDER;
		}
		locationManager.requestLocationUpdates(provider, 5000, 1, locationListener);
		btn_sign.setOnClickListener(this);
		tv_classname.setOnClickListener(this);
		return view;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btn_sign_callname:
			toSign();
			break;

		case R.id.tv_stuClass_callname:
			chooseclass();
			break;
		default:
			break;
		}
	}

	private void chooseclass() {
		SharedPreferences sp = getActivity().getSharedPreferences("RememberUser", Context.MODE_PRIVATE);
		BmobQuery<ClassStu> classquery = new BmobQuery<ClassStu>();

		classquery.addWhereEqualTo("stuName", sp.getString("username", ""));
		classquery.findObjects(new FindListener<ClassStu>() {

			@Override
			public void done(List<ClassStu> list, BmobException e) {
				// TODO Auto-generated method stub
				if (e == null) {
					if (list.size()>0) {
						showDialog(list);
					}
					else{
						Toast.makeText(getActivity(), "���ȼ���һ��Ⱥ��", Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(getActivity(), "����:" + e.getMessage(), Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	private void toSign() {
		// TODO Auto-generated method stub

		if (tv_classname.getText().toString().equals("���ѡ��Ⱥ��")) {
			Toast.makeText(getActivity(), "����ѡ��Ⱥ�飬�ڽ���ǩ��", Toast.LENGTH_SHORT).show();
		} else {

			BmobQuery<Classes> eq1 = new BmobQuery<Classes>();
			eq1.addWhereEqualTo("name", tv_classname.getText().toString());
			BmobQuery<Classes> eq2 = new BmobQuery<Classes>();
			eq2.addWhereEqualTo("teacher", classteacher);
			List<BmobQuery<Classes>> andQuerys = new ArrayList<BmobQuery<Classes>>();
			andQuerys.add(eq1);
			andQuerys.add(eq2);
			BmobQuery<Classes> query = new BmobQuery<Classes>();
			query.and(andQuerys);
			query.findObjects(new FindListener<Classes>() {

				@Override
				public void done(List<Classes> list, BmobException e) {
					// TODO Auto-generated method stub
					if (e == null) {
						Classes cl = list.get(0);
						BmobDate starttime = cl.getStarttime();

						SharedPreferences sp = getActivity().getSharedPreferences("RememberUser", Context.MODE_PRIVATE);
						BmobQuery<SignInfo> eq1 = new BmobQuery<SignInfo>();
						eq1.addWhereEqualTo("classname", tv_classname.getText().toString());
						BmobQuery<SignInfo> eq2 = new BmobQuery<SignInfo>();
						eq2.addWhereEqualTo("teacher", classteacher);
						BmobQuery<SignInfo> eq3 = new BmobQuery<SignInfo>();
						eq3.addWhereGreaterThanOrEqualTo("createdAt", starttime);
						BmobQuery<SignInfo> eq4 = new BmobQuery<SignInfo>();
						eq4.addWhereEqualTo("stuName", sp.getString("username", ""));
						List<BmobQuery<SignInfo>> andQuerys = new ArrayList<BmobQuery<SignInfo>>();
						andQuerys.add(eq1);
						andQuerys.add(eq2);
						andQuerys.add(eq3);
						andQuerys.add(eq4);
						BmobQuery<SignInfo> query = new BmobQuery<SignInfo>();
						query.and(andQuerys);
						query.findObjects(new FindListener<SignInfo>() {

							@Override
							public void done(List<SignInfo> list, BmobException e) {
								// TODO Auto-generated method stub
								if (e != null) {
									Toast.makeText(getActivity(), "����:" + e.getMessage(), Toast.LENGTH_SHORT).show();
									
								} else {
									if (list.size() > 0) {
										Toast.makeText(getActivity(), "����ǩ�����벻Ҫ�ظ�ǩ��", Toast.LENGTH_SHORT).show();
									} else {
										SharedPreferences pref = getActivity().getSharedPreferences("RememberUser",
												Context.MODE_PRIVATE);
										String stuname = pref.getString("username", "");
										SignInfo info = new SignInfo();
										info.setState("��ǩ��");
										info.setStuName(stuname);

										List<String> providerList = locationManager.getProviders(true);
										if (providerList.contains(LocationManager.GPS_PROVIDER)) {
											provider = LocationManager.GPS_PROVIDER;
										} else if (providerList.contains(LocationManager.NETWORK_PROVIDER)) {
											provider = LocationManager.NETWORK_PROVIDER;
										}

										Location location = locationManager.getLastKnownLocation(provider);
										double latitude = 37.87241;
										double longitude = 112.484756;
										if (location != null) {
											latitude = location.getLatitude();
											longitude = location.getLongitude();
										}

										info.setStuRealname(tv_stuname.getText().toString());
										info.setLatitude(latitude);
										info.setLongititude(longitude);
										info.setClassname(tv_classname.getText().toString());
										info.setTeacher(classteacher);
										info.setStuid(tv_stuid.getText().toString());
										info.save(new SaveListener<String>() {

											@Override
											public void done(String arg0, BmobException e) {
												// TODO Auto-generated method
												// stub
												if (e == null) {
													Toast.makeText(getActivity(), "ǩ���ɹ�", Toast.LENGTH_SHORT).show();
												}
											}
										});
									}
								}
							}
						});

					} else {
						Toast.makeText(getActivity(), "����:" + e.getMessage(), Toast.LENGTH_SHORT).show();
					}
				}
			});
		}

	}

	public void showDialog(List<ClassStu> classlist) {

		mapLists = new ArrayList<HashMap<String, Object>>();
		for (int i = 0; i < classlist.size(); i++) {
			ClassStu cs = classlist.get(i);
			String className = cs.getClassName();
			String teacher = cs.getTeacher();
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("name", className);
			map.put("teacher", teacher);
			mapLists.add(map);
		}
		classlist_dialog = new Dialog(getActivity());
		classlist_dialog.setTitle("��ѡ��༶��");
		classlist_dialog.show();

		LayoutInflater inflater = LayoutInflater.from(getActivity());
		View viewDialog = inflater.inflate(R.layout.dialog_classlist_callname, null);
		Display display = getActivity().getWindowManager().getDefaultDisplay();
		int width = display.getWidth();
		// ���öԻ���Ŀ���
		LayoutParams layoutParams = new LayoutParams(width * 80 / 100, LayoutParams.WRAP_CONTENT);
		classlist_dialog.setContentView(viewDialog, layoutParams);

		list_class = (ListView) viewDialog.findViewById(R.id.classlist_dialog);

		classlist_adapter = new SimpleAdapter(getActivity(), mapLists, R.layout.item_classlist_dialog,
				new String[] { "name", "teacher" }, new int[] { R.id.txt_name_classlist, R.id.txt_number_classlist });
		list_class.setAdapter(classlist_adapter);

		list_class.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				HashMap<String, Object> selectMap = mapLists.get(position);
				String name = selectMap.get("name").toString();
				tv_classname.setText(name);
				classteacher = selectMap.get("teacher").toString();
				classlist_dialog.dismiss();
			}

		});

	}

	LocationListener locationListener = new LocationListener() {

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub
			// Toast.makeText(MainActivity.this, "00",
			// Toast.LENGTH_SHORT).show();
		}
	};

}
