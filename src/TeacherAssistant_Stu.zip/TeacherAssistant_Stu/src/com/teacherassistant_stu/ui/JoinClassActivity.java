package com.teacherassistant_stu.ui;

import java.util.ArrayList;
import java.util.List;

import com.teacherassistant.DBmodel.ClassStu;
import com.teacherassistant.DBmodel.Classes;
import com.teacherassistant.DBmodel.SignInfo;
import com.teacherassistant.adapter.ClassListAdapter;
import com.teacherassistant.util.BaseActivity;
import com.teacherassistant_stu.R;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;

public class JoinClassActivity extends BaseActivity implements OnClickListener {

	private List<Classes> classlist = new ArrayList<Classes>();
	private ListView lv_class;
	private Button btn_query;
	private EditText edt_query;
	private ImageView img_back;
	private ClassStu aclass;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_joinclass);

		DBInit();
		initviews();
		initaction();

		// Classes cla = new Classes();
		// cla.setName("����1");
		// cla.setTeacher("С��");
		// cla.setPeoplenumber(5);
		// classlist.add(cla);

	}

	private void initaction() {
		// TODO Auto-generated method stub
		img_back.setOnClickListener(this);
		btn_query.setOnClickListener(this);
		lv_class.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				Classes cla = classlist.get(position);
				joinclass(cla);
			}
		});
	}

	private void initviews() {
		// TODO Auto-generated method stub
		lv_class = (ListView) findViewById(R.id.list_join_class);
		btn_query = (Button) findViewById(R.id.btn_query_join);
		edt_query = (EditText) findViewById(R.id.edt_query_join);
		img_back = (ImageView) findViewById(R.id.img_back_joinclass);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.img_back_joinclass:
			JoinClassActivity.this.finish();
			break;
		case R.id.btn_query_join:
			queryclass();
			break;
		default:
			break;
		}
	}

	private void queryclass() {
		// TODO Auto-generated method stub

		String classname = edt_query.getText().toString();

		if (classname.isEmpty()) {
			BmobQuery<Classes> query = new BmobQuery<Classes>();
			query.findObjects(new FindListener<Classes>() {

				@Override
				public void done(List<Classes> list, BmobException e) {
					// TODO Auto-generated method stub
					if (e == null) {
						if (list.size() == 0) {
							toast("û�в�ѯ���κ����ݣ�");
						}
						classlist.clear();
						for (int i = 0; i < list.size(); i++) {
							Classes cla = list.get(i);
							classlist.add(cla);
						}
						ClassListAdapter adapter = new ClassListAdapter(JoinClassActivity.this,
								R.layout.item_classlist_join, classlist);
						lv_class.setAdapter(adapter);
					} else {
						toast("����" + e.getMessage());
					}
				}
			});
		} else {
			BmobQuery<Classes> query = new BmobQuery<Classes>();
			query.addWhereEqualTo("name", edt_query.getText().toString());
			query.findObjects(new FindListener<Classes>() {

				@Override
				public void done(List<Classes> list, BmobException e) {
					// TODO Auto-generated method stub
					if (e == null) {
						classlist.clear();
						if (list.size() == 0) {
							toast("û�в�ѯ���κ����ݣ�");
						}
						for (int i = 0; i < list.size(); i++) {
							Classes cla = list.get(i);
							classlist.add(cla);
						}
						ClassListAdapter adapter = new ClassListAdapter(JoinClassActivity.this,
								R.layout.item_classlist_join, classlist);
						lv_class.setAdapter(adapter);
					} else {
						toast("����" + e.getMessage());
					}
				}
			});
		}

	}

	private void joinclass(Classes cla) {

		// TODO Auto-generated method stub
		aclass = new ClassStu();
		aclass.setTeacher(cla.getTeacher());
		aclass.setClassName(cla.getName());
		SharedPreferences sp = getSharedPreferences("RememberUser", MODE_PRIVATE);
		aclass.setStuName(sp.getString("username", ""));

		AlertDialog.Builder mdialog = new Builder(JoinClassActivity.this);
		mdialog.setTitle("����Ⱥ��");
		mdialog.setMessage("ȷ������Ⱥ��'" + cla.getName() + "'��");
		mdialog.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				checkinfo();
			}
		});
		mdialog.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub

			}
		});
		mdialog.show();

	}

	private void checkinfo() {
		// TODO Auto-generated method stub
		BmobQuery<ClassStu> eq1 = new BmobQuery<ClassStu>();
		eq1.addWhereEqualTo("stuName", aclass.getStuName());
		BmobQuery<ClassStu> eq2 = new BmobQuery<ClassStu>();
		eq2.addWhereEqualTo("className", aclass.getClassName());
		BmobQuery<ClassStu> eq3 = new BmobQuery<ClassStu>();
		eq3.addWhereEqualTo("teacher", aclass.getTeacher());
		List<BmobQuery<ClassStu>> andQuerys = new ArrayList<BmobQuery<ClassStu>>();
		andQuerys.add(eq1);
		andQuerys.add(eq2);
		andQuerys.add(eq3);
		BmobQuery<ClassStu> query = new BmobQuery<ClassStu>();
		query.and(andQuerys);
		query.findObjects(new FindListener<ClassStu>() {

			@Override
			public void done(List<ClassStu> list, BmobException e) {
				// TODO Auto-generated method stub
				if (e == null) {
					if (list.size()>0) {
						toast("���Ѿ������Ⱥ��");
					} else {
						aclass.save(new SaveListener<String>() {

							@Override
							public void done(String arg0, BmobException e) {
								// TODO Auto-generated method stub
								if (e == null) {
									addpeople();
								} else {
									toast("ʧ�ܣ�" + e.getMessage());
								}
							}

						});
					}

				} else {
					toast("����" + e.getMessage());
				}
			}
		});
	}
	private void addpeople() {
		// TODO Auto-generated method stub
		BmobQuery<Classes> eq2 = new BmobQuery<Classes>();
		eq2.addWhereEqualTo("name", aclass.getClassName());
		BmobQuery<Classes> eq1 = new BmobQuery<Classes>();
		eq1.addWhereEqualTo("teacher", aclass.getTeacher());
		List<BmobQuery<Classes>> andQuerys = new ArrayList<BmobQuery<Classes>>();
		andQuerys.add(eq1);
		andQuerys.add(eq2);
		BmobQuery<Classes> query = new BmobQuery<Classes>();
		query.and(andQuerys);
		query.findObjects(new FindListener<Classes>() {
			
			@Override
			public void done(List<Classes> list, BmobException e) {
				// TODO Auto-generated method stub
				if (e == null ) {
					Classes cl = list.get(0);
					cl.setPeoplenumber(cl.getPeoplenumber()+1);
					cl.update(new UpdateListener() {
						
						@Override
						public void done(BmobException e) {
							// TODO Auto-generated method stub
							if (e==null) {
								toast("�ɹ�����Ⱥ��"+aclass.getClassName()+"!");
								JoinClassActivity.this.finish();
							} else {
								toast("����:"+e.getMessage());
							}
						}
					});
					
				} else {
					toast("����:"+e.getMessage());
				}
			}
		});
	}

}
