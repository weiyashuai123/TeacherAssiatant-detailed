package com.teacherassistant_stu.ui;

import com.teacherassistant.DBmodel.Job;
import com.teacherassistant.util.BaseActivity;
import com.teacherassistant_stu.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class JobInfoActivity extends BaseActivity{

	
	private ImageView img_back;
	private TextView tv_course;
	private TextView tv_content;
	
	private TextView tv_teacher;
	private TextView tv_data;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_jobinfo);
		initView();
	}

	private void initView() {
		// TODO Auto-generated method stub
		Intent intent = getIntent();
		Job job = (Job) intent.getSerializableExtra("job");
		
		
		tv_teacher = (TextView) findViewById(R.id.txt_jobteacher_jobinfo);
		tv_data = (TextView) findViewById(R.id.txt_jobdata_jobinfo);
		
		img_back = (ImageView) findViewById(R.id.img_back_jobinfo);
		tv_content = (TextView) findViewById(R.id.edt_content_jobinfo);
		tv_course = (TextView) findViewById(R.id.edt_course_jobinfo);
		tv_content.setText(job.getJobContent());
		tv_course.setText(job.getCourseName());
		tv_teacher.setText(job.getTeacher());
		tv_data.setText(job.getCreatedAt());
		img_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				JobInfoActivity.this.finish();
			}
		});
	}
}
