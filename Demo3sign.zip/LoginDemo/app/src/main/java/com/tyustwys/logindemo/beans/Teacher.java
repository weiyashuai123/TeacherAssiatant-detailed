package com.tyustwys.logindemo.beans;

import cn.bmob.v3.BmobUser;

/**
 * Created by weiyashuai on 2017/4/10.
 */
public class Teacher extends BmobUser {
    private String sex;
    public Teacher(){}
    public Teacher(String username,String password,String sex){
        this.sex = sex;
        this.setUsername(username);
        this.setPassword(password);
    }
    public void setSex(String sex) {
        this.sex = sex;
    }
    public String getSex() {
        return sex;
    }
}
