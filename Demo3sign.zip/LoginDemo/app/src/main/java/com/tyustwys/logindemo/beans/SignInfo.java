package com.tyustwys.logindemo.beans;

import cn.bmob.v3.BmobObject;

/**
 * Created by weiyashuai on 2017/4/10.
 */
public class SignInfo extends BmobObject{
    private String username;
    private String location;
    public void setUsername(String username) {
        this.username = username;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    public String getLocation() {
        return location;
    }
    public String getUsername() {
        return username;
    }
}
