package com.tyustwys.logindemo.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.tyustwys.logindemo.R;
import com.tyustwys.logindemo.beans.SignInfo;
import com.tyustwys.logindemo.beans.Teacher;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

/**
 * Created by weiyashuai on 2017/4/10.
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn_sign = (Button) findViewById(R.id.btn_sign_main);
        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Teacher teacher = BmobUser.getCurrentUser(Teacher.class);
                SignInfo s = new SignInfo();
                s.setUsername(teacher.getUsername());
                s.setLocation("地球");
                s.save(new SaveListener<String>() {
                    @Override
                    public void done(String s, BmobException e) {
                        if (e==null){
                            Toast.makeText(MainActivity.this, "签到成功", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(MainActivity.this, "失败："+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}
